def contentsRoot = new File("../template");
def output = new File("output");

def htmlTemplate = new groovy.text.SimpleTemplateEngine().createTemplate(new File('templateold.html'))

def traverse(dir, depth, Closure m) {
    dir.eachFile {file ->
        if (file.isFile()) {
            m(depth, file);
        } else if (!file.getName().startsWith('.')) {
            traverse(file, depth + 1, m);
        }
    }
}

if (output.exists()) {
    traverse(output, 0) {depth, file ->
        file.delete();
    }
}

traverse(contentsRoot, 0) {depth, file ->
    if (!file.getName().endsWith(".html")) return

    def map = [title: 'DBFlute', contextRoot: '.', content: ''];

    def text = file.getText();
    def m = (text =~ /(?s).*<title>(.*)<\/title>.*(<div id="content"><!-- __content-start__ -->.*<!-- __content-end__ --><\/div>).*/);
    if (m.matches()) {
        map.title = m[0][1]
        map.content = m[0][2]
    } else {
        println "Failed to parse ${file.getPath()}";
    }

    (0 ..< depth).each {
        map.contextRoot = map.contextRoot.length() == 1 ? ".." : map.contextRoot + "/.."
    }

    def outputFile = new File(output.getPath() + "/" + file.getAbsolutePath().substring(contentsRoot.getAbsolutePath().length()));
    if (!outputFile.getParentFile().exists()) {
        outputFile.getParentFile().mkdirs();
    }

    outputFile.withWriter {
        it.write(htmlTemplate.make(map).toString())
    }
}
