new File('../template').eachFileRecurse{if (it.name ==~ /\..*\.html$/) it.delete()}
