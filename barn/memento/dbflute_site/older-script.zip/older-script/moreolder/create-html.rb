# ・このスクリプトと同じフォルダに、[input]というフォルダを用意し、中にcontentsのHTMLを配置する
#   （.htmlファイルのうち、[__content-start__]の記述のある行から、[__content-end__]の行までが使用される）
# ・このスクリプトと同じフォルダに、[header.txt]というファイルを用意し、中にcontentsより前のHTMLを記述する
# ・このスクリプトと同じフォルダに、[footer.txt]というファイルを用意し、中にcontentsより後のHTMLを記述する
# ・このスクリプトを動かす
# ・outputフォルダに置換したHTMLファイルが出力される
# ※既にoutputフォルダが存在する場合は、実行不可

# == header_print ==
def header_print(out)
	f = open("header.txt")
	out.print(f.read)
	f.close
end
# ==================

# == footer_print ==
def footer_print(out)
	f = open("footer.txt")
	out.print(f.read)
	f.close
end
# ==================

# == make_dir2 =====
def make_dir2(file)
	dirname = File::dirname(file)
	if FileTest::directory?(dirname)
	else
		FileUtils.mkdir_p(dirname)
	end
end
# ==================

# == main ==========
require 'fileutils'
Dir::mkdir("output")
Dir.glob('**/*.html').each { |file|
	newfileName = "output/" + file
	print "-target filename:" + newfileName + "\n"

	make_dir2(newfileName)
	newFile = File.open(newfileName, "w")

	header_print(newFile)

	flg = 0
	IO.foreach(file) {|line|
		case line
			when /__content-start__/
				flg = 1
			when /__content-end__/
				newFile.print(line)
				flg = 0
		end

		if flg == 1
			newFile.print(line)
		end
	}

	footer_print(newFile)
	newFile.close()
}
# ==================
